import 'package:flutter/material.dart';
Widget policyPrivacy(){
  return Container(
    alignment: Alignment.topCenter,
    child: Text(
      "INFORMAZIONI SUL TRATTAMENTO DEI DATI PERSONALI",
      textAlign: TextAlign.center,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 20,
        fontStyle: FontStyle.italic
      ),
    ),
  );
  }